export const METHODS_HTTP = Object.freeze({
    METHOD_GET: 'GET',
    METHOD_POST: 'POST',
    METHOD_PUT: 'PUT',
    METHOD_DELETE: 'DELETE'
})