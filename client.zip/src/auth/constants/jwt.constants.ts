export const jwtConstants = {
    secret: 'dont use this in production'
}