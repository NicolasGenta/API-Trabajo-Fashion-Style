export class AuthResult {
    emprendimiento_id: number | null;
    razon_social: string |null;
    nombre_rubro: string| null;
    usuario_id: number;
    rol_name: string;
    mail: string;
    persona_id: number;
    first_name: string;
    last_name: string;
}